import { createContext, useContext, useState, ReactNode } from "react";
import { User, AuthContextType } from "../types/types";

const AuthContext = createContext<AuthContextType | null>(null);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);

  // Mock users database
  const users: User[] = [
    { id: "1", username: "admin", password: "admin123", role: "admin" },
    { id: "2", username: "user1", password: "user123", role: "user" },
    { id: "3", username: "user2", password: "user123", role: "user" },
  ];

  const login = async (username: string, password: string) => {
    const foundUser = users.find(
      (u) => u.username === username && u.password === password
    );

    if (foundUser) {
      setUser(foundUser);
      return true;
    }
    return false;
  };

  const logout = () => {
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};
